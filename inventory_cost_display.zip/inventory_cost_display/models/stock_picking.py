# -*- coding: utf-8 -*-

from odoo import fields, models


class StockPicking(models.Model):
    _inherit = "stock.picking"

class StockMove(models.Model):
    _inherit = "stock.move"

    cost = fields.Float(
        string='Cost',
        compute='_compute_cost',
    )

    def _compute_cost(self):
        for move in self:
            move.cost = move.product_id.standard_price if move.product_id else 0.0
